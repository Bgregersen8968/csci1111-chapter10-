class Exercise10_3 {
	public static void main(String[] args) {
	MyInteger int1 = new MyInteger(1);
	MyInteger int2 = new MyInteger(34);
	MyInteger int3 = new MyInteger(100);
	MyInteger int4 = new MyInteger(25);
	MyInteger int5 = new MyInteger(1);
	System.out.println("Is " + int1.getValue() + " prime? " + int1.isPrime());
	System.out.println("Is " + int2.getValue() + " prime? " + int2.isPrime());
	System.out.println("Is " + int3.getValue() + " even? " + int3.isEven());
	System.out.println("Is " + int4.getValue() + " even? " + int4.isEven());
	System.out.println("Is " + int1.getValue() + " odd? " + int1.isOdd());	
	System.out.println("Is " + int2.getValue() + " odd? " + int2.isOdd());
	System.out.println( "does " + int1.getValue() + " equal " + int5.getValue()+ "? " + int1.equals(int5));
	System.out.println( "does " + int1.getValue() + " equal " + int4.getValue()+ "? " + int1.equals(int4));	
	System.out.println( "1 + 9 + 3 = " + MyInteger.parseInt(new char[] {'1', '9', '3'}));
	System.out.print( MyInteger.parseInt("1" + "1"));
	}
}
class MyInteger {
	public int value1;
	public MyInteger(int value){
		value1 = value;
	}
	
	public int getValue() {
		return value1;
	}
	public boolean isEven() {
		return (value1 % 2 ) == 0;
	}
	public boolean isOdd() { 
		return (value1 % 2) == 1;
	}
	public boolean isPrime() {
		for (int i = 2; i < value1; i++)
		if ( value1 % i == 0 ){
			return false;
	}
		return true;
	}
	public static boolean isEven(int myInt){
		return (myInt % 2) == 0;	
	}
	
	public static boolean isOdd(int myInt){
		return (myInt % 2 ) == 1;
	}
	
	public static boolean isPrime(int myInt){
		for (int i = 2; i < myInt; i++)
		if ( myInt % i == 0 ){
			return false;
	}
		return true;
	}
	public static boolean isEven(MyInteger myInt){
		return myInt.isEven();
	}
	public static boolean isOdd(MyInteger myInt){
		return myInt.isOdd();
	}
	public static boolean isPrime(MyInteger myInt){
		return myInt.isPrime();
	}
	public boolean equals(int testInt){
		if(testInt == value1)
		return true;
		return false;
	}
	public boolean equals(MyInteger myInt){
		if(myInt.value1 == this.value1)
		return true;
		return false;
	}
	public static int parseInt(char[] values){
	int sum = 0;
	for( char i : values) { 
	sum += Character.getNumericValue(i);
	}
		return sum;
	}
	public static int parseInt(String val){
		return Integer.parseInt(val);
	}
}

