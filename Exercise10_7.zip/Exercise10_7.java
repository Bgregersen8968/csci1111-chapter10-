import java.util.*;
//Scanner in = new Scanner(System.in);
//System.out.print("Enter an ID: ");
class Exercise10_7 {
	public static void main(String[] args) {
Scanner in = new Scanner(System.in);
		Account[] atmAccount = new Account[11];
		int option = 0;
		
		for(int i = 1; i<=10; i++) {
			atmAccount[i] = new Account(i, 100,0,0);
		}
		while(true){
			System.out.print("Please enter I.D. : ");
			int id = in.nextInt();
		
			while (id < 1 || id > 10) {
				System.out.println("Incorrect I.D. ");
				System.out.print("Please Enter I.D. : ");
				id = in.nextInt();
			}
		
				
		while(true)	{	
				System.out.print("\n  Main Menu\n");
				System.out.print("1. Check Balance\n2. Withdraw\n3. Deposite\n4. Exit\nEnter Option: ");
				option = in.nextInt();
				if (option == 1){
					System.out.print("\nyour current balance is: $" + atmAccount[id].getBalance()+"0");
				}else if (option == 2 ){
					System.out.print("\nEnter withdraw amount: $");
					double withdrawAmount = in.nextDouble();
					atmAccount[id].setwithdrawlAmount(withdrawAmount);
				}else if (option == 3){
					System.out.print("\nEnter deposit amount: $");
					double depositAmount = in.nextDouble();
					atmAccount[id].setdepositAmount(depositAmount);
				}else if(option == 4){
					System.out.println();
					break;
				}
			}
		}
	}
}
class Account{
	private int id;
	private double balance;
	private double withdrawlAmount;
	private double depositAmount;
	Account(){}
	
	Account(int id, double balance, double withdrawlAmount, double depositAmount){
		this.id = id;
		this.balance = balance;
		this.withdrawlAmount = withdrawlAmount;
		this.depositAmount = depositAmount;
			}
	
			int getId (){
				return this.id;
			}
	
			void setId(int id){
				this.id = id;
			}
			double getBalance (){
				return this.balance;
			}
			void setBalance (double balance){
				this.balance = balance;
			}
			double getwithdrawlAmount (){
				return this.withdrawlAmount;
			}
			void setwithdrawlAmount (double withdrawlAmount){
				this.balance = (balance-withdrawlAmount);
			}
			double getdepositAmount (){
				return this.depositAmount;
			}
			void setdepositAmount (double depositAmount){
				this.balance = balance + depositAmount;
	}
}
